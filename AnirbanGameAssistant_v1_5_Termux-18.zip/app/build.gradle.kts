plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.anirban.gameassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.anirban.gameassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "1.5"
    }
}
