package com.anirban.gameassistant

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.widget.*
import android.content.Context
import kotlin.math.max

data class MacroPoint(val x: Float, val y: Float, val time: Long, val down: Boolean)

object MacroStore {
    val points = mutableListOf<MacroPoint>()
    var macroName: String = "My Macro"
    var repeatCount: Int = 1
}

class MacroActivity : Activity() {
    private lateinit var pad: RecordPad
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(12, 16, 20))
        }
        val title = TextView(this).apply {
            text = "MACRO RECORDER"; textSize = 22f
            setTextColor(Color.rgb(80,255,130)); setPadding(6,10,6,10)
        }
        root.addView(title)
        val name = EditText(this).apply {
            setText(MacroStore.macroName); hint = "Macro name"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(name)
        status = TextView(this).apply {
            text = "Record taps and drags on the pad below."
            setTextColor(Color.WHITE); setPadding(6,8,6,8)
        }
        root.addView(status)
        pad = RecordPad(this)
        root.addView(pad, LinearLayout.LayoutParams(-1, 0, 1f))
        fun button(text: String, fn: () -> Unit) {
            root.addView(Button(this).apply { this.text = text; setOnClickListener { fn() } })
        }
        button("START / CLEAR RECORDING") {
            MacroStore.points.clear()
            pad.recording = true
            status.text = "Recording on pad…"
            pad.invalidate()
        }
        button("STOP & SAVE") {
            pad.recording = false
            MacroStore.macroName = name.text.toString().ifBlank { "My Macro" }
            status.text = "Saved for this app session: ${MacroStore.points.size} points (${MacroStore.macroName}). Not saved permanently."
            pad.invalidate()
        }
        button("STOP MACRO") {
            AutoClickAccessibilityService.instance?.stopMacroPlayback()
            status.text = "Stop requested. Current gesture may finish first."
        }
        button("PLAY MACRO ON SCREEN") {
            pad.recording = false
            val svc = AutoClickAccessibilityService.instance
            if (svc == null) {
                status.text = "Enable this app's Accessibility service first."
            } else if (MacroStore.points.isEmpty()) {
                status.text = "Record a macro first."
            } else {
                svc.playMacro(MacroStore.points.toList(), pad.width.toFloat(), pad.height.toFloat(), MacroStore.repeatCount)
                status.text = "Playing recorded pad gesture. It records only this app's pad, not touches inside other games."
            }
        }
        val repeats = Spinner(this)
        repeats.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Repeat 1X","Repeat 2X","Repeat 5X"))
        repeats.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                MacroStore.repeatCount = listOf(1,2,5)[position]
            }
        }
        root.addView(repeats)
        button("DONE") { finish() }
        setContentView(root)
    }

    class RecordPad(context: Context) : View(context) {
        var recording = false
        private val paint = Paint(3)
        private var startedAt = 0L
        init { setBackgroundColor(Color.rgb(28,38,34)) }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            paint.color = Color.rgb(90,255,140); paint.textSize = 38f
            c.drawText(if (recording) "RECORDING…" else "TOUCH / DRAG PAD", 18f, 55f, paint)
            paint.textSize = 22f
            c.drawText("Saved points: ${MacroStore.points.size}", 18f, 90f, paint)
            val pts = MacroStore.points
            for (i in pts.indices) {
                val p = pts[i]
                c.drawCircle(p.x * width, p.y * height, 7f, paint)
                if (i > 0) {
                    val prev = pts[i-1]
                    c.drawLine(prev.x*width, prev.y*height, p.x*width, p.y*height, paint)
                }
            }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (!recording) return true
            when (e.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    val now = android.os.SystemClock.uptimeMillis()
                    if (startedAt == 0L) startedAt = now
                    val down = e.action != MotionEvent.ACTION_UP
                    MacroStore.points.add(MacroPoint(
                        (e.x / max(1f,width.toFloat())).coerceIn(0f,1f),
                        (e.y / max(1f,height.toFloat())).coerceIn(0f,1f),
                        now-startedAt, down
                    ))
                    invalidate()
                    if (e.action == MotionEvent.ACTION_UP) startedAt = 0L
                }
            }
            return true
        }
    }
}
