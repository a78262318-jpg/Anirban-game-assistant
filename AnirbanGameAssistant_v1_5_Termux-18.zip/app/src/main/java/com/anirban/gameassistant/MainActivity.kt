package com.anirban.gameassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(Color.rgb(12, 16, 20))
        }
        box.addView(TextView(this).apply {
            text = "ANIRBAN GAME ASSISTANT"; textSize = 23f
            setTextColor(Color.rgb(90, 255, 140)); setPadding(12, 16, 12, 12)
        })
        box.addView(TextView(this).apply {
            text = "Floating panel • Auto Tap • Macro tools • Device & battery info"
            textSize = 15f; setTextColor(Color.WHITE); setPadding(12, 8, 12, 16)
        })
        box.addView(button("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        box.addView(button("2. Enable Auto Tap accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        box.addView(button("3. Start floating assistant") {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, FloatingService::class.java))
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        setContentView(box)
    }
}
